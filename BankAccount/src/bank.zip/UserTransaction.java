import java.io.*;

public class UserTransaction {

	public static void main(String[] args) {
		UserAccount account1 = new UserAccount("Giulio", 1000);	
		System.out.println("Please enter deposit/withdrawl amount:");
		int firstArg;
		for (String s: args){
			if (s == "deposit"){
				if (args.length > 0) {
					try {
						firstArg = Integer.parseInt(args[1]);
						account1.Deposit(firstArg);
					} catch (NumberFormatException e) {
						System.err.println("Argument" + args[1] + " must be an integer.");
						System.exit(1);
					}
				}
			}
			if (s == "withdrawal"){
				if (args.length > 0) {
					try {
						firstArg = Integer.parseInt(args[1]);
						account1.Deposit(firstArg);
					} catch (NumberFormatException e) {
						System.err.println("Argument" + args[1] + " must be an integer.");
						System.exit(1);
					}
				}
			}
		}
	}
}




